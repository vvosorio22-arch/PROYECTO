"""Punto de entrada del sistema Software FJ.

Ejecuta las 14 simulaciones automáticas, imprime el resumen ejecutivo
en consola y deja toda la evidencia en ``sistema.log``. La aplicación
nunca se detiene por una excepción y siempre retorna el código 0.

Responsable: Dev 5 — rama ``feature/simulaciones-docs``.
"""

from __future__ import annotations

import logging

from src.gestor import GestorSoftwareFJ
from src.logger_config import obtener_logger, registrar_evento, registrar_excepcion
from src.simulaciones import ejecutar_todas, imprimir_resumen


def main() -> int:
    """Ejecuta el programa completo de forma segura.

    Estructura ``try/except/finally``: cualquier error inesperado se
    captura y registra; el ``finally`` asegura el cierre del logging.
    Siempre retorna 0.

    Returns:
        Código de salida del proceso (0 en todos los casos).
    """
    logger = obtener_logger()
    registrar_evento(logger, "Inicio de la ejecución de Software FJ.")
    gestor = GestorSoftwareFJ()
    try:
        resultados = ejecutar_todas(gestor)
        imprimir_resumen(resultados, gestor)
    except Exception as e:  # noqa: BLE001 - red de seguridad global
        registrar_excepcion(logger, e, contexto="main")
        print(
            f"ERROR INESPERADO controlado en main(): "
            f"{type(e).__name__}: {e}"
        )
    finally:
        registrar_evento(logger, "Fin de la ejecución de Software FJ.")
        logging.shutdown()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
