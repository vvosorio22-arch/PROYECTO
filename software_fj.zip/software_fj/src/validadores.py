"""Funciones de validación reutilizables del sistema Software FJ.

Cada validador lanza :class:`DatoInvalidoError` (FJ-001) cuando el
valor no cumple la regla correspondiente y devuelve el valor
normalizado cuando es válido.

Responsable: Dev 2 — rama ``feature/modelos-base-cliente``.
"""

from __future__ import annotations

import math
import re

from src.excepciones import DatoInvalidoError

_PATRON_EMAIL: str = r"^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$"
_PATRON_DOCUMENTO: str = r"^\d{6,12}$"
_PATRON_TELEFONO: str = r"^\d{7,10}$"


def validar_texto_no_vacio(valor: str, campo: str) -> str:
    """Valida que un texto no sea vacío ni esté compuesto solo de espacios.

    Args:
        valor: Texto a validar.
        campo: Nombre del campo (para el mensaje de error).

    Returns:
        El texto validado sin espacios al inicio ni al final.

    Raises:
        DatoInvalidoError: Si el valor no es texto o está vacío.
    """
    if not isinstance(valor, str) or not valor.strip():
        raise DatoInvalidoError(f"El campo '{campo}' no puede estar vacío.")
    return valor.strip()


def validar_email(valor: str) -> str:
    """Valida que el valor tenga formato de correo electrónico.

    Args:
        valor: Correo a validar.

    Returns:
        El correo validado sin espacios al inicio ni al final.

    Raises:
        DatoInvalidoError: Si el formato no es válido.
    """
    texto = validar_texto_no_vacio(valor, "correo")
    if not re.fullmatch(_PATRON_EMAIL, texto):
        raise DatoInvalidoError(
            f"El correo '{valor}' no tiene un formato válido."
        )
    return texto


def validar_documento(valor: str) -> str:
    """Valida que el documento tenga entre 6 y 12 dígitos numéricos.

    Args:
        valor: Documento a validar.

    Returns:
        El documento validado.

    Raises:
        DatoInvalidoError: Si no cumple el patrón de dígitos.
    """
    texto = validar_texto_no_vacio(valor, "documento")
    if not re.fullmatch(_PATRON_DOCUMENTO, texto):
        raise DatoInvalidoError(
            f"El documento '{valor}' debe tener entre 6 y 12 dígitos."
        )
    return texto


def validar_telefono(valor: str) -> str:
    """Valida que el teléfono tenga entre 7 y 10 dígitos numéricos.

    Args:
        valor: Teléfono a validar.

    Returns:
        El teléfono validado.

    Raises:
        DatoInvalidoError: Si no cumple el patrón de dígitos.
    """
    texto = validar_texto_no_vacio(valor, "teléfono")
    if not re.fullmatch(_PATRON_TELEFONO, texto):
        raise DatoInvalidoError(
            f"El teléfono '{valor}' debe tener entre 7 y 10 dígitos."
        )
    return texto


def validar_numero_positivo(valor: float, campo: str) -> float:
    """Valida que un número sea finito y estrictamente mayor que cero.

    Rechaza explícitamente valores booleanos y ``NaN``.

    Args:
        valor: Número a validar.
        campo: Nombre del campo (para el mensaje de error).

    Returns:
        El valor convertido a ``float``.

    Raises:
        DatoInvalidoError: Si el valor no es un número positivo finito.
    """
    if isinstance(valor, bool):
        raise DatoInvalidoError(
            f"El campo '{campo}' no acepta valores booleanos."
        )
    try:
        numero = float(valor)
    except (TypeError, ValueError) as e:
        raise DatoInvalidoError(
            f"El campo '{campo}' debe ser un número positivo."
        ) from e
    if math.isnan(numero) or not math.isfinite(numero) or numero <= 0:
        raise DatoInvalidoError(
            f"El campo '{campo}' debe ser un número positivo y finito."
        )
    return numero


def validar_porcentaje(valor: float, campo: str) -> float:
    """Valida que un número esté en el rango cerrado [0, 100].

    Rechaza explícitamente valores booleanos y ``NaN``.

    Args:
        valor: Porcentaje a validar.
        campo: Nombre del campo (para el mensaje de error).

    Returns:
        El valor convertido a ``float``.

    Raises:
        DatoInvalidoError: Si el valor está fuera del rango 0 a 100.
    """
    if isinstance(valor, bool):
        raise DatoInvalidoError(
            f"El campo '{campo}' no acepta valores booleanos."
        )
    try:
        numero = float(valor)
    except (TypeError, ValueError) as e:
        raise DatoInvalidoError(
            f"El campo '{campo}' debe ser un porcentaje entre 0 y 100."
        ) from e
    if math.isnan(numero) or not math.isfinite(numero):
        raise DatoInvalidoError(
            f"El campo '{campo}' debe ser un porcentaje finito."
        )
    if numero < 0 or numero > 100:
        raise DatoInvalidoError(
            f"El campo '{campo}' debe estar entre 0 y 100 (recibido: {numero})."
        )
    return numero
