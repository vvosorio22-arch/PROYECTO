"""Clase abstracta base de todas las entidades del sistema Software FJ.

Responsable: Dev 2 — rama ``feature/modelos-base-cliente``.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from datetime import datetime
from typing import ClassVar


class EntidadSistema(ABC):
    """Entidad base con identificador único y fecha de creación.

    Atributos de clase:
        _contador: Contador compartido para generar IDs autoincrementales
            con formato ``ENT-0001``.
    """

    _contador: ClassVar[int] = 0

    def __init__(self) -> None:
        """Asigna un ID único autoincremental y la fecha de creación."""
        EntidadSistema._contador += 1
        self._id: str = f"ENT-{EntidadSistema._contador:04d}"
        self._fecha_creacion: datetime = datetime.now()

    @property
    def id(self) -> str:
        """Devuelve el identificador único de la entidad."""
        return self._id

    @property
    def fecha_creacion(self) -> datetime:
        """Devuelve la fecha y hora de creación de la entidad."""
        return self._fecha_creacion

    @abstractmethod
    def validar(self) -> bool:
        """Valida el estado interno de la entidad.

        Returns:
            ``True`` si la entidad es válida.

        Raises:
            SoftwareFJError: Si la entidad no cumple las reglas de negocio.
        """

    @abstractmethod
    def resumen(self) -> str:
        """Devuelve un resumen legible en una línea de la entidad."""

    def __str__(self) -> str:
        """Delega la representación en texto a :meth:`resumen`."""
        return self.resumen()
