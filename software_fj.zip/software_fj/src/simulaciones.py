"""Simulaciones automáticas del sistema Software FJ.

Ejecuta 14 escenarios de prueba aislados en memoria, cada uno dentro
de un bloque ``try/except`` amplio que registra el resultado y permite
que la aplicación nunca se detenga por un error.

Responsable: Dev 5 — rama ``feature/simulaciones-docs``.
"""

from __future__ import annotations

from typing import Any, Callable

from src.alquiler_equipo import AlquilerEquipo
from src.asesoria_especializada import AsesoriaEspecializada
from src.cliente import Cliente
from src.excepciones import ReservaInvalidaError
from src.gestor import GestorSoftwareFJ
from src.logger_config import LOG_FILE, obtener_logger, registrar_excepcion
from src.reserva import EstadoReserva, Reserva
from src.reserva_sala import ReservaSala


def ejecutar_simulacion(
    nombre: str,
    funcion: Callable[[], Any],
    resultados: list[dict],
) -> None:
    """Ejecuta una simulación aislada y registra su resultado.

    Captura cualquier excepción (incluso no previstas), la registra en
    el log y guarda el estado en ``resultados``; la ejecución continúa
    con la siguiente simulación.

    Args:
        nombre: Nombre identificador de la simulación (p. ej. "SIM-01").
        funcion: Callable sin argumentos que ejecuta el escenario.
        resultados: Lista compartida donde se agrega el resultado.
    """
    logger = obtener_logger()
    try:
        resultado = funcion()
    except Exception as e:  # noqa: BLE001 - captura amplia a propósito
        registrar_excepcion(logger, e, contexto=f"Simulación {nombre}")
        causa = (
            f" | causa={e.__cause__!r}" if e.__cause__ is not None else ""
        )
        resultados.append(
            {
                "nombre": nombre,
                "estado": "ERROR CONTROLADO",
                "detalle": f"{type(e).__name__}: {e}{causa}",
            }
        )
    else:
        if isinstance(resultado, tuple) and len(resultado) == 2:
            estado, detalle = resultado
        else:
            estado, detalle = "OK", str(resultado)
        resultados.append(
            {"nombre": nombre, "estado": estado, "detalle": detalle}
        )


def _reportar(
    numero: int, descripcion: str, ok: bool, detalle: str
) -> tuple[str, str]:
    """Imprime la línea estándar y devuelve el resultado de la simulación.

    Returns:
        Tupla ``(estado, detalle)`` lista para registrarse en los
        resultados de ``ejecutar_simulacion``.
    """
    estado = "OK" if ok else "ERROR CONTROLADO"
    sufijo = f" ({detalle})" if detalle else ""
    print(f"[SIM-{numero:02d}] {descripcion} → {estado}{sufijo}")
    return estado, detalle or estado


def _error_controlado(
    numero: int, descripcion: str, e: Exception
) -> tuple[str, str]:
    """Registra la excepción en el log y reporta el error controlado.

    Args:
        numero: Número de la simulación.
        descripcion: Descripción del escenario.
        e: Excepción capturada dentro de la simulación.

    Returns:
        Tupla ``(estado, detalle)`` con estado ``ERROR CONTROLADO``.
    """
    registrar_excepcion(
        obtener_logger(), e, contexto=f"SIM-{numero:02d} {descripcion}"
    )
    return _reportar(numero, descripcion, False, type(e).__name__)


def sim_01_cliente_valido(g: GestorSoftwareFJ) -> str:
    """SIM-01: registro de un cliente con datos completamente válidos."""
    descripcion = "Cliente válido"
    cliente = g.registrar_cliente(
        "Juan Pérez", "1023456789", "juan.perez@correo.com", "3001234567"
    )
    if cliente is None:
        return _reportar(1, descripcion, False, "registro rechazado")
    return _reportar(1, descripcion, True, f"registrado con id {cliente.id}")


def sim_02_cliente_nombre_vacio(g: GestorSoftwareFJ) -> str:
    """SIM-02: cliente con nombre vacío → DatoInvalidoError controlado."""
    descripcion = "Cliente con nombre vacío"
    try:
        Cliente("   ", "1023456789", "a@correo.com", "3001234567")
    except Exception as e:
        return _error_controlado(2, descripcion, e)
    return _reportar(2, descripcion, False, "se esperaba DatoInvalidoError")


def sim_03_cliente_email_mal_formado(g: GestorSoftwareFJ) -> str:
    """SIM-03: cliente con correo sin formato válido → DatoInvalidoError."""
    descripcion = "Cliente con email mal formado"
    try:
        Cliente("María López", "1023456789", "correo-sin-arroba", "3001234567")
    except Exception as e:
        return _error_controlado(3, descripcion, e)
    return _reportar(3, descripcion, False, "se esperaba DatoInvalidoError")


def sim_04_cliente_documento_invalido(g: GestorSoftwareFJ) -> str:
    """SIM-04: cliente con documento de 4 dígitos → DatoInvalidoError."""
    descripcion = "Cliente con documento inválido"
    try:
        Cliente("Carlos Ruiz", "1234", "carlos@correo.com", "3001234567")
    except Exception as e:
        return _error_controlado(4, descripcion, e)
    return _reportar(4, descripcion, False, "se esperaba DatoInvalidoError")


def sim_05_servicio_sala_valido(g: GestorSoftwareFJ) -> str:
    """SIM-05: registro de una sala válida y cálculo de su costo."""
    descripcion = "Servicio sala válido"
    sala = ReservaSala("Sala A", 50000.0, 20, tiene_proyector=True)
    registrada = g.registrar_servicio(sala)
    if registrada is None:
        return _reportar(5, descripcion, False, "registro rechazado")
    costo = sala.calcular_costo(2.0)
    return _reportar(
        5, descripcion, True, f"id {sala.id} | costo 2h = {costo}"
    )


def sim_06_equipo_tarifa_negativa(g: GestorSoftwareFJ) -> str:
    """SIM-06: equipo con tarifa negativa → DatoInvalidoError controlado."""
    descripcion = "Equipo con tarifa negativa"
    try:
        AlquilerEquipo("Portátil HP", -15000.0, "computador")
    except Exception as e:
        return _error_controlado(6, descripcion, e)
    return _reportar(6, descripcion, False, "se esperaba DatoInvalidoError")


def sim_07_asesoria_modalidad_invalida(g: GestorSoftwareFJ) -> str:
    """SIM-07: asesoría con modalidad inválida → DatoInvalidoError."""
    descripcion = "Asesoría con modalidad inválida"
    try:
        AsesoriaEspecializada(
            "Consultoría TI", 80000.0, "seguridad", modalidad="híbrida"
        )
    except Exception as e:
        return _error_controlado(7, descripcion, e)
    return _reportar(7, descripcion, False, "se esperaba DatoInvalidoError")


def sim_08_costos_con_ajustes(g: GestorSoftwareFJ) -> str:
    """SIM-08: costo normal, con descuento 10 %, IVA19 y dict combinado."""
    descripcion = "Costos con ajustes variados"
    sala = ReservaSala("Sala B", 100000.0, 10)
    normal = sala.calcular_costo(1.0)
    con_descuento = sala.calcular_costo(1.0, descuento=10.0)
    con_iva = sala.aplicar_ajuste("IVA19", normal)
    combinado = sala.aplicar_ajuste(
        {"descuento": 10.0, "impuesto": 19.0, "recargo": 5.0}, normal
    )
    detalle = (
        f"normal={normal} | desc10={con_descuento} | IVA19={con_iva} "
        f"| dict={combinado}"
    )
    return _reportar(8, descripcion, True, detalle)


def sim_09_descuento_excesivo(g: GestorSoftwareFJ) -> str:
    """SIM-09: descuento del 150 % → CalculoInconsistenteError."""
    descripcion = "Descuento 150 % → CalculoInconsistenteError"
    sala = ReservaSala("Sala C", 50000.0, 8)
    try:
        sala.calcular_costo(1.0, descuento=150.0)
    except Exception as e:
        return _error_controlado(9, descripcion, e)
    return _reportar(
        9, descripcion, False, "se esperaba CalculoInconsistenteError"
    )


def sim_10_reserva_exitosa(g: GestorSoftwareFJ) -> str:
    """SIM-10: flujo completo crear → confirmar → procesar."""
    descripcion = "Reserva exitosa (crear → confirmar → procesar)"
    cliente = g.registrar_cliente(
        "Ana Gómez", "1030456789", "ana@correo.com", "3109876543"
    )
    sala = g.registrar_servicio(ReservaSala("Sala D", 60000.0, 15))
    if cliente is None or sala is None:
        return _reportar(10, descripcion, False, "falló el registro previo")
    reserva = g.crear_reserva(cliente.id, sala.id, 3.0)
    if reserva is None:
        return _reportar(10, descripcion, False, "no se pudo crear")
    if not g.confirmar_reserva(reserva.id):
        return _reportar(10, descripcion, False, "no se pudo confirmar")
    costo = g.procesar_reserva(reserva.id, descuento=10.0)
    if costo is None:
        return _reportar(10, descripcion, False, "no se pudo procesar")
    return _reportar(
        10, descripcion, True, f"costo total con descuento 10 % = {costo}"
    )


def sim_11_servicio_no_disponible(g: GestorSoftwareFJ) -> str:
    """SIM-11: confirmar reserva de servicio no disponible → FJ-005."""
    descripcion = "Reserva con servicio no disponible"
    cliente = g.registrar_cliente(
        "Luis Díaz", "1045678901", "luis@correo.com", "3204567890"
    )
    equipo = AlquilerEquipo("Proyector", 30000.0, "audiovisual")
    equipo.disponible = False
    g.registrar_servicio(equipo)
    if cliente is None:
        return _reportar(11, descripcion, False, "falló el registro previo")
    reserva = g.crear_reserva(cliente.id, equipo.id, 2.0)
    if reserva is None:
        return _reportar(11, descripcion, False, "no se pudo crear")
    try:
        reserva.confirmar()
    except Exception as e:
        return _error_controlado(11, descripcion, e)
    return _reportar(
        11, descripcion, False, "se esperaba ServicioNoDisponibleError"
    )


def sim_12_cancelar_reserva_procesada(g: GestorSoftwareFJ) -> str:
    """SIM-12: cancelar una reserva ya procesada → OperacionNoPermitidaError."""
    descripcion = "Cancelar reserva ya procesada"
    cliente = g.registrar_cliente(
        "Sofía Torres", "1056789012", "sofia@correo.com", "3156789012"
    )
    asesoria = g.registrar_servicio(
        AsesoriaEspecializada("Mentoría", 70000.0, "desarrollo")
    )
    if cliente is None or asesoria is None:
        return _reportar(12, descripcion, False, "falló el registro previo")
    reserva = g.crear_reserva(cliente.id, asesoria.id, 1.5)
    if reserva is None or not g.confirmar_reserva(reserva.id):
        return _reportar(12, descripcion, False, "no se pudo confirmar")
    if g.procesar_reserva(reserva.id) is None:
        return _reportar(12, descripcion, False, "no se pudo procesar")
    try:
        reserva.cancelar()
    except Exception as e:
        return _error_controlado(12, descripcion, e)
    return _reportar(
        12, descripcion, False, "se esperaba OperacionNoPermitidaError"
    )


def sim_13_duracion_invalida(g: GestorSoftwareFJ) -> str:
    """SIM-13: crear reserva con duración 0 → ReservaInvalidaError."""
    descripcion = "Duración inválida (0 o negativa)"
    cliente = g.registrar_cliente(
        "Pedro Vargas", "1067890123", "pedro@correo.com", "3012340987"
    )
    sala = ReservaSala("Sala E", 40000.0, 6)
    g.registrar_servicio(sala)
    if cliente is None:
        return _reportar(13, descripcion, False, "falló el registro previo")
    try:
        Reserva(cliente, sala, 0)
    except Exception as e:
        return _error_controlado(13, descripcion, e)
    return _reportar(13, descripcion, False, "se esperaba ReservaInvalidaError")


def sim_14_cliente_inexistente(g: GestorSoftwareFJ) -> str:
    """SIM-14: reserva con cliente inexistente → raise from e + __cause__."""
    descripcion = "Cliente inexistente (raise ... from e)"
    controlado = g.crear_reserva("ENT-9999", "ENT-0001", 1.0)
    if controlado is not None:
        return _reportar(14, descripcion, False, "debió devolver None")
    try:
        cliente = g._clientes["ENT-9999"]
    except KeyError as e:
        raise ReservaInvalidaError(
            "Cliente inexistente: 'ENT-9999'."
        ) from e
    return _reportar(
        14, descripcion, False, f"objeto inesperado: {cliente!r}"
    )


_SIMULACIONES: list[tuple[int, Callable[[GestorSoftwareFJ], str]]] = [
    (1, sim_01_cliente_valido),
    (2, sim_02_cliente_nombre_vacio),
    (3, sim_03_cliente_email_mal_formado),
    (4, sim_04_cliente_documento_invalido),
    (5, sim_05_servicio_sala_valido),
    (6, sim_06_equipo_tarifa_negativa),
    (7, sim_07_asesoria_modalidad_invalida),
    (8, sim_08_costos_con_ajustes),
    (9, sim_09_descuento_excesivo),
    (10, sim_10_reserva_exitosa),
    (11, sim_11_servicio_no_disponible),
    (12, sim_12_cancelar_reserva_procesada),
    (13, sim_13_duracion_invalida),
    (14, sim_14_cliente_inexistente),
]


def ejecutar_todas(gestor: GestorSoftwareFJ) -> list[dict]:
    """Ejecuta las 14 simulaciones sobre el gestor recibido.

    Args:
        gestor: Instancia del gestor sobre la que corren las simulaciones.

    Returns:
        Lista de diccionarios con ``nombre``, ``estado`` y ``detalle``.
    """
    resultados: list[dict] = []
    print("=" * 70)
    print("SOFTWARE FJ — SIMULACIONES AUTOMÁTICAS")
    print("=" * 70)
    for numero, funcion in _SIMULACIONES:
        ejecutar_simulacion(
            f"SIM-{numero:02d}", lambda f=funcion: f(gestor), resultados
        )
    return resultados


def imprimir_resumen(
    resultados: list[dict], gestor: GestorSoftwareFJ
) -> None:
    """Imprime el resumen ejecutivo final en consola.

    Args:
        resultados: Lista de resultados devuelta por ``ejecutar_todas``.
        gestor: Gestor usado durante las simulaciones.
    """
    ok = sum(1 for r in resultados if r["estado"] == "OK")
    errores = len(resultados) - ok
    print()
    print("=" * 70)
    print("RESUMEN EJECUTIVO — SOFTWARE FJ")
    print("=" * 70)
    for r in resultados:
        print(f"  {r['nombre']:<9} {r['estado']:<17} {r['detalle']}")
    print("-" * 70)
    print(
        f"Total simulaciones: {len(resultados)} | OK: {ok} | "
        f"Errores controlados: {errores}"
    )
    print(gestor.resumen_ejecutivo())
    try:
        with open(LOG_FILE, encoding="utf-8") as archivo:
            entradas = sum(1 for _ in archivo)
    except OSError:
        entradas = 0
    print(f"Entradas registradas en {LOG_FILE}: {entradas}")
    print("=" * 70)
