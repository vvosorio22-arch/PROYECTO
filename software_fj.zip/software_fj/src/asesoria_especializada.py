"""Servicio de asesoría especializada del sistema Software FJ.

Responsable: Dev 3 — rama ``feature/servicios-polimorfismo``.
"""

from __future__ import annotations

from src.excepciones import DatoInvalidoError, ParametroFaltanteError
from src.servicio import Servicio
from src.validadores import validar_texto_no_vacio

_MODALIDADES_VALIDAS: frozenset[str] = frozenset({"remota", "presencial"})
_RECARGO_PRESENCIAL: float = 15.0


class AsesoriaEspecializada(Servicio):
    """Servicio de asesoría especializada con cobro por hora.

    La modalidad presencial aplica un recargo fijo del 15 % sobre el
    costo base.
    """

    def __init__(
        self,
        nombre: str,
        tarifa_hora: float,
        especialidad: str,
        modalidad: str = "remota",
        disponible: bool = True,
    ) -> None:
        """Crea una asesoría validando especialidad y modalidad.

        Args:
            nombre: Nombre de la asesoría.
            tarifa_hora: Tarifa de cobro por hora.
            especialidad: Área de especialidad.
            modalidad: "remota" o "presencial".
            disponible: Indica si la asesoría puede contratarse.

        Raises:
            DatoInvalidoError: Si la modalidad no es válida.
        """
        super().__init__(nombre, tarifa_hora, disponible)
        if modalidad not in _MODALIDADES_VALIDAS:
            raise DatoInvalidoError(
                f"Modalidad inválida: '{modalidad}'. "
                f"Use 'remota' o 'presencial'."
            )
        self._especialidad: str = validar_texto_no_vacio(
            especialidad, "especialidad"
        )
        self._modalidad: str = modalidad

    @property
    def especialidad(self) -> str:
        """Devuelve la especialidad de la asesoría."""
        return self._especialidad

    @property
    def modalidad(self) -> str:
        """Devuelve la modalidad de la asesoría (remota o presencial)."""
        return self._modalidad

    def calcular_costo(
        self,
        duracion: float,
        *,
        descuento: float | None = None,
        impuesto: float | None = None,
        recargo: float | None = None,
    ) -> float:
        """Calcula el costo de la asesoría por horas.

        La modalidad presencial suma un recargo del 15 % adicional
        sobre cualquier recargo explícito recibido.

        Args:
            duracion: Cantidad de horas de asesoría.
            descuento: Porcentaje de descuento (0 a 100) o ``None``.
            impuesto: Porcentaje de impuesto (0 a 100) o ``None``.
            recargo: Porcentaje de recargo (0 a 100) o ``None``.

        Returns:
            Costo total redondeado a dos decimales.

        Raises:
            CalculoInconsistenteError: Si el cálculo es inválido.
        """
        recargo_total = (recargo or 0.0) + (
            _RECARGO_PRESENCIAL if self._modalidad == "presencial" else 0.0
        )
        return self._calcular_base(
            duracion,
            descuento,
            impuesto,
            recargo_total if recargo_total > 0 else None,
        )

    def describir_servicio(self) -> str:
        """Devuelve una descripción legible de la asesoría."""
        return (
            f"Asesoría '{self._nombre}' | especialidad={self._especialidad} "
            f"| modalidad={self._modalidad} | tarifa/hora={self._tarifa_base}"
        )

    def validar_parametros(self) -> bool:
        """Valida que la asesoría tenga parámetros coherentes.

        Returns:
            ``True`` si los parámetros son válidos.

        Raises:
            ParametroFaltanteError: Si falta el nombre o la especialidad.
            DatoInvalidoError: Si la modalidad o la tarifa no son válidas.
        """
        if not self._nombre or not self._nombre.strip():
            raise ParametroFaltanteError(
                "El nombre de la asesoría es un parámetro obligatorio."
            )
        if not self._especialidad or not self._especialidad.strip():
            raise ParametroFaltanteError(
                "La especialidad es un parámetro obligatorio."
            )
        if self._modalidad not in _MODALIDADES_VALIDAS:
            raise DatoInvalidoError(
                f"Modalidad inválida: '{self._modalidad}'."
            )
        if self._tarifa_base <= 0:
            raise DatoInvalidoError("La tarifa por hora debe ser positiva.")
        return True
