"""Servicio de alquiler de equipos del sistema Software FJ.

Responsable: Dev 3 — rama ``feature/servicios-polimorfismo``.
"""

from __future__ import annotations

from src.excepciones import DatoInvalidoError
from src.servicio import Servicio
from src.validadores import validar_numero_positivo, validar_texto_no_vacio


class AlquilerEquipo(Servicio):
    """Servicio de alquiler de equipos con cobro por día.

    El costo se calcula como tarifa por día * cantidad de equipos,
    más un depósito único que se suma una sola vez al total.
    """

    def __init__(
        self,
        nombre: str,
        tarifa_dia: float,
        tipo_hardware: str,
        cantidad: int = 1,
        deposito: float = 0.0,
        disponible: bool = True,
    ) -> None:
        """Crea un alquiler de equipo validando sus parámetros.

        Args:
            nombre: Nombre del equipo.
            tarifa_dia: Tarifa de cobro por día.
            tipo_hardware: Categoría del equipo.
            cantidad: Número de unidades a alquilar (entero positivo).
            deposito: Valor del depósito reembolsable (mayor o igual a 0).
            disponible: Indica si el equipo puede alquilarse.

        Raises:
            DatoInvalidoError: Si cantidad o depósito no son válidos.
        """
        super().__init__(nombre, tarifa_dia, disponible)
        if isinstance(cantidad, bool) or not isinstance(cantidad, int):
            raise DatoInvalidoError(
                f"La cantidad debe ser un entero (recibido: {cantidad!r})."
            )
        if cantidad <= 0:
            raise DatoInvalidoError(
                f"La cantidad debe ser positiva (recibido: {cantidad})."
            )
        if deposito != 0.0:
            validar_numero_positivo(deposito, "depósito")
        self._tipo_hardware: str = validar_texto_no_vacio(
            tipo_hardware, "tipo_hardware"
        )
        self._cantidad: int = cantidad
        self._deposito: float = float(deposito)

    @property
    def tipo_hardware(self) -> str:
        """Devuelve la categoría del equipo."""
        return self._tipo_hardware

    @property
    def cantidad(self) -> int:
        """Devuelve la cantidad de unidades alquiladas."""
        return self._cantidad

    @property
    def deposito(self) -> float:
        """Devuelve el valor del depósito."""
        return self._deposito

    def calcular_costo(
        self,
        duracion: float,
        *,
        descuento: float | None = None,
        impuesto: float | None = None,
        recargo: float | None = None,
    ) -> float:
        """Calcula el costo del alquiler por días.

        El depósito se suma una sola vez, sin aplicarle descuento,
        impuesto ni recargo.

        Args:
            duracion: Cantidad de días de alquiler.
            descuento: Porcentaje de descuento (0 a 100) o ``None``.
            impuesto: Porcentaje de impuesto (0 a 100) o ``None``.
            recargo: Porcentaje de recargo (0 a 100) o ``None``.

        Returns:
            Costo total redondeado a dos decimales.

        Raises:
            CalculoInconsistenteError: Si el cálculo es inválido.
        """
        subtotal = self._calcular_base(
            duracion, descuento, impuesto, recargo, factor_extra=self._cantidad
        )
        return round(subtotal + self._deposito, 2)

    def describir_servicio(self) -> str:
        """Devuelve una descripción legible del alquiler."""
        return (
            f"Alquiler '{self._nombre}' | tipo={self._tipo_hardware} "
            f"| cantidad={self._cantidad} | tarifa/día={self._tarifa_base} "
            f"| depósito={self._deposito}"
        )

    def validar_parametros(self) -> bool:
        """Valida que el alquiler tenga parámetros coherentes.

        Returns:
            ``True`` si los parámetros son válidos.

        Raises:
            ParametroFaltanteError: Si falta el nombre o el tipo.
            DatoInvalidoError: Si cantidad, tarifa o depósito no son válidos.
        """
        from src.excepciones import ParametroFaltanteError

        if not self._nombre or not self._nombre.strip():
            raise ParametroFaltanteError(
                "El nombre del equipo es un parámetro obligatorio."
            )
        if not self._tipo_hardware or not self._tipo_hardware.strip():
            raise ParametroFaltanteError(
                "El tipo de hardware es un parámetro obligatorio."
            )
        if self._cantidad <= 0:
            raise DatoInvalidoError("La cantidad debe ser positiva.")
        if self._tarifa_base <= 0:
            raise DatoInvalidoError("La tarifa por día debe ser positiva.")
        if self._deposito < 0:
            raise DatoInvalidoError("El depósito no puede ser negativo.")
        return True
