"""Clase abstracta base de los servicios ofrecidos por Software FJ.

Incluye la lógica común de cálculo de costos y la sobrecarga
simulada mediante ``@singledispatchmethod`` en :meth:`aplicar_ajuste`.

Responsable: Dev 3 — rama ``feature/servicios-polimorfismo``.
"""

from __future__ import annotations

import math
from abc import ABC, abstractmethod
from functools import singledispatchmethod

from src.entidad import EntidadSistema
from src.excepciones import CalculoInconsistenteError, DatoInvalidoError
from src.logger_config import obtener_logger, registrar_evento
from src.validadores import validar_numero_positivo, validar_texto_no_vacio


class Servicio(EntidadSistema, ABC):
    """Servicio ofrecido por el sistema, con tarifa base y disponibilidad.

    Las subclases implementan de forma polimórfica el cálculo del costo
    según la unidad de cobro propia de cada servicio (horas o días).
    """

    def __init__(
        self,
        nombre: str,
        tarifa_base: float,
        disponible: bool = True,
    ) -> None:
        """Crea un servicio validando nombre y tarifa base.

        Args:
            nombre: Nombre descriptivo del servicio.
            tarifa_base: Tarifa de referencia (debe ser positiva).
            disponible: Indica si el servicio puede reservarse.

        Raises:
            DatoInvalidoError: Si el nombre es vacío o la tarifa no es
                un número positivo.
        """
        super().__init__()
        self.nombre: str = nombre
        self.tarifa_base: float = tarifa_base
        self.disponible: bool = disponible

    @property
    def nombre(self) -> str:
        """Devuelve el nombre del servicio."""
        return self._nombre

    @nombre.setter
    def nombre(self, valor: str) -> None:
        """Asigna el nombre validando que no sea vacío."""
        self._nombre = validar_texto_no_vacio(valor, "nombre del servicio")

    @property
    def tarifa_base(self) -> float:
        """Devuelve la tarifa base del servicio."""
        return self._tarifa_base

    @tarifa_base.setter
    def tarifa_base(self, valor: float) -> None:
        """Asigna la tarifa base validando que sea un número positivo."""
        self._tarifa_base = validar_numero_positivo(valor, "tarifa_base")

    @property
    def disponible(self) -> bool:
        """Devuelve ``True`` si el servicio está disponible."""
        return self._disponible

    @disponible.setter
    def disponible(self, valor: bool) -> None:
        """Asigna la disponibilidad validando que sea booleana."""
        if not isinstance(valor, bool):
            raise DatoInvalidoError(
                f"La disponibilidad debe ser booleana (recibido: {valor!r})."
            )
        self._disponible = valor

    @abstractmethod
    def calcular_costo(
        self,
        duracion: float,
        *,
        descuento: float | None = None,
        impuesto: float | None = None,
        recargo: float | None = None,
    ) -> float:
        """Calcula el costo del servicio de forma polimórfica.

        Args:
            duracion: Cantidad de unidades de cobro (horas o días).
            descuento: Porcentaje de descuento (0 a 100) o ``None``.
            impuesto: Porcentaje de impuesto (0 a 100) o ``None``.
            recargo: Porcentaje de recargo (0 a 100) o ``None``.

        Returns:
            Costo total calculado, redondeado a dos decimales.

        Raises:
            CalculoInconsistenteError: Si el resultado es inválido.
        """

    @abstractmethod
    def describir_servicio(self) -> str:
        """Devuelve una descripción legible del servicio."""

    @abstractmethod
    def validar_parametros(self) -> bool:
        """Valida los parámetros propios del servicio.

        Returns:
            ``True`` si los parámetros son válidos.

        Raises:
            ParametroFaltanteError: Si falta un parámetro obligatorio.
        """

    @singledispatchmethod
    def aplicar_ajuste(self, ajuste: object, base: float) -> float:
        """Aplica un ajuste al costo base según el tipo recibido.

        Sobrecarga simulada:
            - ``float`` / ``int``: descuento porcentual.
            - ``str``: impuesto predefinido ("IVA19" o "IVA5").
            - ``dict``: combinación de descuento, impuesto y recargo.

        Args:
            ajuste: Ajuste a aplicar (float, int, str o dict).
            base: Costo base sobre el que se aplica el ajuste.

        Returns:
            Costo ajustado, redondeado a dos decimales.

        Raises:
            DatoInvalidoError: Si el tipo o el valor del ajuste no es
                soportado.
        """
        raise DatoInvalidoError(
            f"Tipo de ajuste no soportado: {type(ajuste).__name__}."
        )

    @aplicar_ajuste.register(float)
    @aplicar_ajuste.register(int)
    def _(self, ajuste: float, base: float) -> float:
        """Aplica un descuento porcentual (float o int) sobre la base."""
        if ajuste < 0 or ajuste > 100:
            raise DatoInvalidoError(
                f"El descuento debe estar entre 0 y 100 (recibido: {ajuste})."
            )
        return round(base * (1 - ajuste / 100), 2)

    @aplicar_ajuste.register(str)
    def _(self, ajuste: str, base: float) -> float:
        """Aplica un impuesto predefinido ("IVA19" o "IVA5") sobre la base."""
        impuestos = {"IVA19": 19.0, "IVA5": 5.0}
        if ajuste not in impuestos:
            raise DatoInvalidoError(
                f"Impuesto no reconocido: '{ajuste}'. Use 'IVA19' o 'IVA5'."
            )
        return round(base * (1 + impuestos[ajuste] / 100), 2)

    @aplicar_ajuste.register(dict)
    def _(self, ajuste: dict, base: float) -> float:
        """Aplica una combinación de descuento, impuesto y recargo.

        El diccionario puede contener las claves ``"descuento"``,
        ``"impuesto"`` y ``"recargo"`` con porcentajes numéricos;
        cualquier clave ausente o con valor ``None`` se ignora.
        """
        total = base
        descuento = ajuste.get("descuento")
        impuesto = ajuste.get("impuesto")
        recargo = ajuste.get("recargo")
        if descuento is not None:
            total = self.aplicar_ajuste(float(descuento), total)
        if impuesto is not None:
            total = round(total * (1 + float(impuesto) / 100), 2)
        if recargo is not None:
            total = round(total * (1 + float(recargo) / 100), 2)
        return total

    def _calcular_base(
        self,
        duracion: float,
        descuento: float | None,
        impuesto: float | None,
        recargo: float | None,
        factor_extra: float = 1.0,
    ) -> float:
        """Calcula el costo con la lógica común de todos los servicios.

        Orden de aplicación: base * duración * factor_extra, luego
        descuento, luego impuesto y finalmente recargo (todos en
        porcentaje). Cualquier resultado no finito, menor o igual a
        cero, o con descuento mayor a 100, se reporta como
        :class:`CalculoInconsistenteError` con causa encadenada.

        Args:
            duracion: Unidades de cobro (horas o días).
            descuento: Porcentaje de descuento (0 a 100) o ``None``.
            impuesto: Porcentaje de impuesto (0 a 100) o ``None``.
            recargo: Porcentaje de recargo (0 a 100) o ``None``.
            factor_extra: Factor multiplicativo propio del servicio.

        Returns:
            Costo total redondeado a dos decimales.

        Raises:
            CalculoInconsistenteError: Si el cálculo es inconsistente.
        """
        try:
            unidades = validar_numero_positivo(duracion, "duración")
            if factor_extra <= 0:
                raise ValueError(
                    f"El factor extra debe ser positivo (recibido: {factor_extra})."
                )
            total = self._tarifa_base * unidades * factor_extra
            if descuento is not None:
                porcentaje = float(descuento)
                if porcentaje < 0 or porcentaje > 100:
                    raise ValueError(
                        f"El descuento debe estar entre 0 y 100 (recibido: {porcentaje})."
                    )
                total -= total * porcentaje / 100
            if impuesto is not None:
                valor_impuesto = float(impuesto)
                if valor_impuesto < 0 or valor_impuesto > 100:
                    raise ValueError(
                        f"El impuesto debe estar entre 0 y 100 (recibido: {valor_impuesto})."
                    )
                total += total * valor_impuesto / 100
            if recargo is not None:
                valor_recargo = float(recargo)
                if valor_recargo < 0 or valor_recargo > 100:
                    raise ValueError(
                        f"El recargo debe estar entre 0 y 100 (recibido: {valor_recargo})."
                    )
                total += total * valor_recargo / 100
            if total <= 0 or not math.isfinite(total):
                raise ValueError(f"El resultado del cálculo es inválido: {total}")
            return round(total, 2)
        except SoftwareFJErrorConocida:
            raise
        except Exception as e:
            registrar_evento(
                obtener_logger(),
                f"CalculoInconsistenteError en {self._id}: {e}",
                nivel=40,
            )
            raise CalculoInconsistenteError(
                f"Cálculo inconsistente del costo para '{self._nombre}': {e}"
            ) from e

    def validar(self) -> bool:
        """Delega la validación en :meth:`validar_parametros`."""
        return self.validar_parametros()

    def resumen(self) -> str:
        """Devuelve un resumen en una línea del servicio."""
        return (
            f"Servicio {self._id} | {self._nombre} "
            f"| tarifa_base={self._tarifa_base} "
            f"| disponible={self._disponible}"
        )


# Alias interno para re-lanzar errores de dominio sin re-encadenarlos.
from src.excepciones import SoftwareFJError as SoftwareFJErrorConocida  # noqa: E402
