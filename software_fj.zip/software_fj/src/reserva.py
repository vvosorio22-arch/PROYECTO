"""Modelo de la reserva del sistema Software FJ.

Responsable: Dev 4 — rama ``feature/reservas-gestor``.
"""

from __future__ import annotations

from enum import Enum

from src.cliente import Cliente
from src.entidad import EntidadSistema
from src.excepciones import (
    OperacionNoPermitidaError,
    ReservaInvalidaError,
    ServicioNoDisponibleError,
    SoftwareFJError,
)
from src.logger_config import obtener_logger, registrar_evento, registrar_excepcion
from src.servicio import Servicio


class EstadoReserva(Enum):
    """Estados posibles de una reserva en su ciclo de vida."""

    PENDIENTE = "PENDIENTE"
    CONFIRMADA = "CONFIRMADA"
    CANCELADA = "CANCELADA"


class Reserva(EntidadSistema):
    """Reserva de un servicio por parte de un cliente.

    Ciclo de vida: ``PENDIENTE`` → ``CONFIRMADA`` → procesada.
    Una reserva ya procesada no puede cancelarse.
    """

    def __init__(
        self, cliente: Cliente, servicio: Servicio, duracion: float
    ) -> None:
        """Crea una reserva en estado PENDIENTE.

        Args:
            cliente: Cliente que realiza la reserva.
            servicio: Servicio a reservar.
            duracion: Duración de la reserva (debe ser positiva).

        Raises:
            ReservaInvalidaError: Si la duración es menor o igual a cero.
        """
        super().__init__()
        try:
            if isinstance(duracion, bool) or float(duracion) <= 0:
                raise ValueError(
                    f"La duración debe ser un número positivo (recibido: {duracion})."
                )
        except (TypeError, ValueError) as e:
            raise ReservaInvalidaError(
                f"Duración inválida para la reserva: {e}"
            ) from e
        self._cliente: Cliente = cliente
        self._servicio: Servicio = servicio
        self._duracion: float = float(duracion)
        self._estado: EstadoReserva = EstadoReserva.PENDIENTE
        self._procesada: bool = False
        self._costo_total: float = 0.0

    @property
    def cliente(self) -> Cliente:
        """Devuelve el cliente de la reserva."""
        return self._cliente

    @property
    def servicio(self) -> Servicio:
        """Devuelve el servicio reservado."""
        return self._servicio

    @property
    def duracion(self) -> float:
        """Devuelve la duración de la reserva."""
        return self._duracion

    @property
    def estado(self) -> EstadoReserva:
        """Devuelve el estado actual de la reserva."""
        return self._estado

    @property
    def procesada(self) -> bool:
        """Devuelve ``True`` si la reserva ya fue procesada."""
        return self._procesada

    @property
    def costo_total(self) -> float:
        """Devuelve el costo total calculado al procesar la reserva."""
        return self._costo_total

    def confirmar(self) -> None:
        """Confirma la reserva (solo desde estado PENDIENTE).

        Estructura ``try/except/else``: valida el estado y la
        disponibilidad del servicio; si todo es correcto, cambia el
        estado a ``CONFIRMADA`` dentro del ``else``.

        Raises:
            ReservaInvalidaError: Si la reserva no está PENDIENTE.
            ServicioNoDisponibleError: Si el servicio no está disponible.
        """
        logger = obtener_logger()
        try:
            if self._estado is not EstadoReserva.PENDIENTE:
                raise ReservaInvalidaError(
                    f"No se puede confirmar una reserva en estado "
                    f"{self._estado.name}."
                )
            if not self._servicio.disponible:
                raise ServicioNoDisponibleError(
                    f"El servicio '{self._servicio.nombre}' no está disponible."
                )
        except SoftwareFJError as e:
            registrar_excepcion(logger, e, contexto="Reserva.confirmar")
            raise
        else:
            self._estado = EstadoReserva.CONFIRMADA
            registrar_evento(
                logger, f"Reserva {self._id} confirmada correctamente."
            )

    def cancelar(self) -> None:
        """Cancela la reserva (si no ha sido procesada).

        Raises:
            OperacionNoPermitidaError: Si la reserva ya fue procesada o
                ya estaba cancelada.
        """
        logger = obtener_logger()
        if self._procesada:
            raise OperacionNoPermitidaError(
                f"No se puede cancelar la reserva {self._id}: ya fue procesada."
            )
        if self._estado is EstadoReserva.CANCELADA:
            raise OperacionNoPermitidaError(
                f"La reserva {self._id} ya está cancelada."
            )
        self._estado = EstadoReserva.CANCELADA
        registrar_evento(logger, f"Reserva {self._id} cancelada.")

    def procesar(self, **ajustes: float) -> float:
        """Procesa la reserva confirmada y calcula el costo total.

        Estructura ``try/except/finally``: exige estado ``CONFIRMADA``,
        calcula el costo con los ajustes recibidos y marca la reserva
        como procesada. Cualquier error de dominio se envuelve en
        :class:`ReservaInvalidaError` con causa encadenada. El bloque
        ``finally`` registra siempre el intento de procesamiento.

        Args:
            **ajustes: Parámetros opcionales para el cálculo
                (``descuento``, ``impuesto``, ``recargo``).

        Returns:
            Costo total de la reserva.

        Raises:
            ReservaInvalidaError: Si la reserva no pudo procesarse.
        """
        logger = obtener_logger()
        try:
            if self._estado is not EstadoReserva.CONFIRMADA:
                raise OperacionNoPermitidaError(
                    f"La reserva {self._id} debe estar CONFIRMADA para "
                    f"procesarse (estado actual: {self._estado.name})."
                )
            costo = self._servicio.calcular_costo(self._duracion, **ajustes)
            self._costo_total = costo
            self._procesada = True
            registrar_evento(
                logger,
                f"Reserva {self._id} procesada. Costo total: {costo}.",
            )
            return costo
        except SoftwareFJError as e:
            registrar_excepcion(logger, e, contexto="Reserva.procesar")
            raise ReservaInvalidaError(
                f"Error al procesar la reserva {self._id}: {e}"
            ) from e
        finally:
            registrar_evento(
                logger,
                f"Intento de procesar la reserva {self._id} "
                f"(estado={self._estado.name}).",
            )

    def validar(self) -> bool:
        """Valida que cliente y servicio de la reserva sean válidos.

        Returns:
            ``True`` si ambas entidades son válidas; ``False`` si alguna
            lanza un error de dominio.
        """
        try:
            return bool(self._cliente.validar() and self._servicio.validar())
        except SoftwareFJError:
            return False

    def resumen(self) -> str:
        """Devuelve un resumen en una línea de la reserva."""
        return (
            f"Reserva {self._id} | cliente={self._cliente.id} "
            f"| servicio={self._servicio.id} | duración={self._duracion} "
            f"| estado={self._estado.name} | procesada={self._procesada} "
            f"| costo_total={self._costo_total}"
        )
