"""Servicio de reserva de salas del sistema Software FJ.

Responsable: Dev 3 — rama ``feature/servicios-polimorfismo``.
"""

from __future__ import annotations

from src.excepciones import DatoInvalidoError, ParametroFaltanteError
from src.servicio import Servicio


class ReservaSala(Servicio):
    """Servicio de reserva de salas con cobro por hora.

    Si la sala tiene proyector se aplica un factor extra del 10 %
    sobre el costo base.
    """

    def __init__(
        self,
        nombre: str,
        tarifa_hora: float,
        capacidad: int,
        tiene_proyector: bool = False,
        disponible: bool = True,
    ) -> None:
        """Crea una sala validando capacidad y proyector.

        Args:
            nombre: Nombre de la sala.
            tarifa_hora: Tarifa de cobro por hora.
            capacidad: Capacidad de personas (entero positivo).
            tiene_proyector: Indica si la sala cuenta con proyector.
            disponible: Indica si la sala puede reservarse.

        Raises:
            DatoInvalidoError: Si la capacidad no es un entero positivo
                o ``tiene_proyector`` no es booleano.
        """
        super().__init__(nombre, tarifa_hora, disponible)
        if isinstance(capacidad, bool) or not isinstance(capacidad, int):
            raise DatoInvalidoError(
                f"La capacidad debe ser un entero (recibido: {capacidad!r})."
            )
        if capacidad <= 0:
            raise DatoInvalidoError(
                f"La capacidad debe ser positiva (recibido: {capacidad})."
            )
        if not isinstance(tiene_proyector, bool):
            raise DatoInvalidoError(
                "tiene_proyector debe ser un valor booleano."
            )
        self._capacidad: int = capacidad
        self._tiene_proyector: bool = tiene_proyector

    @property
    def capacidad(self) -> int:
        """Devuelve la capacidad de personas de la sala."""
        return self._capacidad

    @property
    def tiene_proyector(self) -> bool:
        """Devuelve ``True`` si la sala tiene proyector."""
        return self._tiene_proyector

    def calcular_costo(
        self,
        duracion: float,
        *,
        descuento: float | None = None,
        impuesto: float | None = None,
        recargo: float | None = None,
    ) -> float:
        """Calcula el costo de la reserva de sala por horas.

        Args:
            duracion: Cantidad de horas de reserva.
            descuento: Porcentaje de descuento (0 a 100) o ``None``.
            impuesto: Porcentaje de impuesto (0 a 100) o ``None``.
            recargo: Porcentaje de recargo (0 a 100) o ``None``.

        Returns:
            Costo total redondeado a dos decimales.

        Raises:
            CalculoInconsistenteError: Si el cálculo es inválido.
        """
        factor_extra = 1.10 if self._tiene_proyector else 1.0
        return self._calcular_base(
            duracion, descuento, impuesto, recargo, factor_extra=factor_extra
        )

    def describir_servicio(self) -> str:
        """Devuelve una descripción legible de la sala."""
        proyector = "con proyector" if self._tiene_proyector else "sin proyector"
        return (
            f"Sala '{self._nombre}' | capacidad={self._capacidad} personas "
            f"| {proyector} | tarifa/hora={self._tarifa_base}"
        )

    def validar_parametros(self) -> bool:
        """Valida que la sala tenga nombre y parámetros coherentes.

        Returns:
            ``True`` si los parámetros son válidos.

        Raises:
            ParametroFaltanteError: Si el nombre está vacío.
            DatoInvalidoError: Si la capacidad o la tarifa no son válidas.
        """
        if not self._nombre or not self._nombre.strip():
            raise ParametroFaltanteError(
                "El nombre de la sala es un parámetro obligatorio."
            )
        if self._capacidad <= 0:
            raise DatoInvalidoError("La capacidad debe ser positiva.")
        if self._tarifa_base <= 0:
            raise DatoInvalidoError("La tarifa por hora debe ser positiva.")
        return True
