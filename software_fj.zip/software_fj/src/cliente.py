"""Modelo del cliente del sistema Software FJ.

Responsable: Dev 2 — rama ``feature/modelos-base-cliente``.
"""

from __future__ import annotations

from src.entidad import EntidadSistema
from src.validadores import (
    validar_documento,
    validar_email,
    validar_telefono,
    validar_texto_no_vacio,
)


class Cliente(EntidadSistema):
    """Cliente del sistema con datos de contacto encapsulados.

    Todos los atributos son privados y se acceden mediante propiedades
    con validación en los ``setter``.
    """

    def __init__(
        self,
        nombre: str,
        documento: str,
        correo: str,
        telefono: str,
    ) -> None:
        """Crea un cliente validando todos sus datos de contacto.

        Args:
            nombre: Nombre completo del cliente.
            documento: Documento de identidad (6 a 12 dígitos).
            correo: Correo electrónico con formato válido.
            telefono: Teléfono de contacto (7 a 10 dígitos).

        Raises:
            DatoInvalidoError: Si algún dato no supera la validación.
        """
        super().__init__()
        self.nombre: str = nombre
        self.documento: str = documento
        self.correo: str = correo
        self.telefono: str = telefono

    @property
    def nombre(self) -> str:
        """Devuelve el nombre del cliente."""
        return self._nombre

    @nombre.setter
    def nombre(self, valor: str) -> None:
        """Asigna el nombre validando que no sea vacío."""
        self._nombre = validar_texto_no_vacio(valor, "nombre")

    @property
    def documento(self) -> str:
        """Devuelve el documento del cliente."""
        return self._documento

    @documento.setter
    def documento(self, valor: str) -> None:
        """Asigna el documento validando el patrón de dígitos."""
        self._documento = validar_documento(valor)

    @property
    def correo(self) -> str:
        """Devuelve el correo del cliente."""
        return self._correo

    @correo.setter
    def correo(self, valor: str) -> None:
        """Asigna el correo validando su formato."""
        self._correo = validar_email(valor)

    @property
    def telefono(self) -> str:
        """Devuelve el teléfono del cliente."""
        return self._telefono

    @telefono.setter
    def telefono(self, valor: str) -> None:
        """Asigna el teléfono validando el patrón de dígitos."""
        self._telefono = validar_telefono(valor)

    def validar(self) -> bool:
        """Revalida todos los datos del cliente.

        Returns:
            ``True`` si todos los datos son válidos.

        Raises:
            DatoInvalidoError: Si algún dato actual no es válido.
        """
        validar_texto_no_vacio(self._nombre, "nombre")
        validar_documento(self._documento)
        validar_email(self._correo)
        validar_telefono(self._telefono)
        return True

    def resumen(self) -> str:
        """Devuelve un resumen en una línea del cliente."""
        return (
            f"Cliente {self._id} | {self._nombre} | doc={self._documento} "
            f"| correo={self._correo} | tel={self._telefono}"
        )
