"""Gestor central del sistema Software FJ.

Administra los clientes, servicios y reservas en memoria y garantiza
que ningún error de dominio (``SoftwareFJError``) se propague al
exterior: captura, registra en el log y devuelve ``None`` o ``False``.

Responsable: Dev 4 — rama ``feature/reservas-gestor``.
"""

from __future__ import annotations

from src.cliente import Cliente
from src.excepciones import ReservaInvalidaError, SoftwareFJError
from src.logger_config import obtener_logger, registrar_evento, registrar_excepcion
from src.reserva import Reserva
from src.servicio import Servicio


class GestorSoftwareFJ:
    """Gestor en memoria de clientes, servicios y reservas."""

    def __init__(self) -> None:
        """Inicializa los diccionarios en memoria y el logger."""
        self._clientes: dict[str, Cliente] = {}
        self._servicios: dict[str, Servicio] = {}
        self._reservas: dict[str, Reserva] = {}
        self._logger = obtener_logger()

    def registrar_cliente(
        self,
        nombre: str,
        documento: str,
        correo: str,
        telefono: str,
    ) -> Cliente | None:
        """Registra un cliente validando sus datos.

        Estructura ``try/except/else``: el registro en el diccionario y
        el log de éxito ocurren únicamente si la creación fue válida.

        Args:
            nombre: Nombre completo del cliente.
            documento: Documento de identidad.
            correo: Correo electrónico.
            telefono: Teléfono de contacto.

        Returns:
            El cliente registrado, o ``None`` si los datos son inválidos.
        """
        try:
            cliente = Cliente(nombre, documento, correo, telefono)
        except SoftwareFJError as e:
            registrar_excepcion(
                self._logger, e, contexto="Gestor.registrar_cliente"
            )
            return None
        else:
            self._clientes[cliente.id] = cliente
            registrar_evento(
                self._logger,
                f"Cliente registrado: {cliente.id} - {cliente.nombre}.",
            )
            return cliente

    def registrar_servicio(self, servicio: Servicio) -> Servicio | None:
        """Registra un servicio en el sistema.

        Args:
            servicio: Instancia de una subclase de ``Servicio``.

        Returns:
            El servicio registrado, o ``None`` si no es válido.
        """
        try:
            if not isinstance(servicio, Servicio):
                raise ReservaInvalidaError(
                    "El objeto registrado no es un servicio válido."
                )
            servicio.validar()
        except SoftwareFJError as e:
            registrar_excepcion(
                self._logger, e, contexto="Gestor.registrar_servicio"
            )
            return None
        self._servicios[servicio.id] = servicio
        registrar_evento(
            self._logger,
            f"Servicio registrado: {servicio.id} - {servicio.nombre}.",
        )
        return servicio

    def crear_reserva(
        self, id_cliente: str, id_servicio: str, duracion: float
    ) -> Reserva | None:
        """Crea una reserva entre un cliente y un servicio existentes.

        Un ``KeyError`` por identificador inexistente se convierte en
        :class:`ReservaInvalidaError` con causa encadenada
        (``raise ... from e``).

        Args:
            id_cliente: ID del cliente.
            id_servicio: ID del servicio.
            duracion: Duración de la reserva.

        Returns:
            La reserva creada, o ``None`` si no pudo crearse.
        """
        try:
            try:
                cliente = self._clientes[id_cliente]
            except KeyError as e:
                raise ReservaInvalidaError(
                    f"Cliente inexistente: '{id_cliente}'."
                ) from e
            try:
                servicio = self._servicios[id_servicio]
            except KeyError as e:
                raise ReservaInvalidaError(
                    f"Servicio inexistente: '{id_servicio}'."
                ) from e
            reserva = Reserva(cliente, servicio, duracion)
        except SoftwareFJError as e:
            registrar_excepcion(
                self._logger, e, contexto="Gestor.crear_reserva"
            )
            return None
        self._reservas[reserva.id] = reserva
        registrar_evento(
            self._logger,
            f"Reserva creada: {reserva.id} (cliente={id_cliente}, "
            f"servicio={id_servicio}).",
        )
        return reserva

    def confirmar_reserva(self, id_reserva: str) -> bool:
        """Confirma una reserva existente.

        Args:
            id_reserva: ID de la reserva.

        Returns:
            ``True`` si se confirmó; ``False`` en cualquier otro caso.
        """
        try:
            reserva = self._reservas[id_reserva]
            reserva.confirmar()
        except KeyError as e:
            registrar_excepcion(
                self._logger,
                ReservaInvalidaError(f"Reserva inexistente: '{id_reserva}'."),
                contexto="Gestor.confirmar_reserva",
            )
            return False
        except SoftwareFJError as e:
            registrar_excepcion(
                self._logger, e, contexto="Gestor.confirmar_reserva"
            )
            return False
        return True

    def procesar_reserva(
        self, id_reserva: str, **ajustes: float
    ) -> float | None:
        """Procesa una reserva confirmada.

        Args:
            id_reserva: ID de la reserva.
            **ajustes: Parámetros opcionales de cálculo.

        Returns:
            El costo total, o ``None`` si no pudo procesarse.
        """
        try:
            reserva = self._reservas[id_reserva]
            return reserva.procesar(**ajustes)
        except KeyError:
            registrar_excepcion(
                self._logger,
                ReservaInvalidaError(f"Reserva inexistente: '{id_reserva}'."),
                contexto="Gestor.procesar_reserva",
            )
            return None
        except SoftwareFJError as e:
            registrar_excepcion(
                self._logger, e, contexto="Gestor.procesar_reserva"
            )
            return None

    def cancelar_reserva(self, id_reserva: str) -> bool:
        """Cancela una reserva existente.

        Args:
            id_reserva: ID de la reserva.

        Returns:
            ``True`` si se canceló; ``False`` en cualquier otro caso.
        """
        try:
            reserva = self._reservas[id_reserva]
            reserva.cancelar()
        except KeyError:
            registrar_excepcion(
                self._logger,
                ReservaInvalidaError(f"Reserva inexistente: '{id_reserva}'."),
                contexto="Gestor.cancelar_reserva",
            )
            return False
        except SoftwareFJError as e:
            registrar_excepcion(
                self._logger, e, contexto="Gestor.cancelar_reserva"
            )
            return False
        return True

    def listar_clientes(self) -> list[Cliente]:
        """Devuelve la lista de clientes registrados."""
        return list(self._clientes.values())

    def listar_servicios(self) -> list[Servicio]:
        """Devuelve la lista de servicios registrados."""
        return list(self._servicios.values())

    def listar_reservas(self) -> list[Reserva]:
        """Devuelve la lista de reservas registradas."""
        return list(self._reservas.values())

    def resumen_ejecutivo(self) -> str:
        """Devuelve un resumen ejecutivo del estado del sistema.

        Returns:
            Texto con totales de clientes, servicios y reservas.
        """
        procesadas = [r for r in self._reservas.values() if r.procesada]
        ingresos = sum(r.costo_total for r in procesadas)
        return (
            f"Clientes: {len(self._clientes)} | "
            f"Servicios: {len(self._servicios)} | "
            f"Reservas: {len(self._reservas)} | "
            f"Reservas procesadas: {len(procesadas)} | "
            f"Ingresos por reservas procesadas: {ingresos:.2f}"
        )
