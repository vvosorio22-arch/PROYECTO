"""Paquete fuente del proyecto Software FJ.

Este archivo queda intencionalmente vacío para que el directorio ``src``
sea un paquete Python importable desde ``main.py`` en la raíz del proyecto.
"""
