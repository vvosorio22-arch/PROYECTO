"""Configuración centralizada del sistema de logging de Software FJ.

Única persistencia permitida del proyecto: el archivo ``sistema.log``.
El módulo nunca propaga errores de configuración: si el archivo no puede
abrirse, cae silenciosamente a un ``StreamHandler`` de consola.

Responsable: Dev 1 — rama ``feature/excepciones-logs``.
"""

from __future__ import annotations

import logging
import traceback

LOG_FILE: str = "sistema.log"

_FORMATO: str = "%(asctime)s | %(levelname)s | %(name)s | %(message)s"


def obtener_logger(nombre: str = "SoftwareFJ") -> logging.Logger:
    """Obtiene un logger configurado de forma idempotente.

    Si el logger aún no tiene handlers, le agrega un ``FileHandler``
    hacia ``sistema.log`` (codificación UTF-8, modo append). Si el
    archivo no puede abrirse, usa un ``StreamHandler`` de consola.
    En ningún caso lanza excepciones.

    Args:
        nombre: Nombre del logger a obtener.

    Returns:
        Instancia de ``logging.Logger`` lista para usar.
    """
    logger = logging.getLogger(nombre)
    try:
        if not logger.handlers:
            try:
                handler: logging.Handler = logging.FileHandler(
                    LOG_FILE, encoding="utf-8", mode="a"
                )
            except OSError:
                handler = logging.StreamHandler()
            handler.setFormatter(logging.Formatter(_FORMATO))
            logger.addHandler(handler)
            logger.setLevel(logging.INFO)
    except Exception:
        # Jamás propagar errores de configuración de logging.
        if not logger.handlers:
            logger.addHandler(logging.StreamHandler())
        logger.setLevel(logging.INFO)
    return logger


def registrar_excepcion(
    logger: logging.Logger,
    exc: BaseException,
    contexto: str = "",
    nivel: int = logging.ERROR,
) -> None:
    """Registra una excepción en el log con tipo, mensaje, contexto y causa.

    Args:
        logger: Logger donde se escribe el registro.
        exc: Excepción a registrar.
        contexto: Texto descriptivo del lugar donde ocurrió el error.
        nivel: Nivel de logging a utilizar (por defecto ``ERROR``).
    """
    try:
        causa = (
            f"{type(exc.__cause__).__name__}: {exc.__cause__}"
            if exc.__cause__ is not None
            else "sin causa encadenada"
        )
        logger.log(
            nivel,
            "EXCEPCIÓN | tipo=%s | mensaje=%s | contexto=%s | causa=%s\n%s",
            type(exc).__name__,
            exc,
            contexto or "sin contexto",
            causa,
            "".join(
                traceback.format_exception(
                    type(exc), exc, exc.__traceback__
                )
            ).strip(),
        )
    except Exception:
        # El registro jamás debe romper la aplicación.
        pass


def registrar_evento(
    logger: logging.Logger, mensaje: str, nivel: int = logging.INFO
) -> None:
    """Registra un evento informativo en el log.

    Args:
        logger: Logger donde se escribe el evento.
        mensaje: Descripción del evento.
        nivel: Nivel de logging (por defecto ``INFO``).
    """
    try:
        logger.log(nivel, "EVENTO | %s", mensaje)
    except Exception:
        # El registro jamás debe romper la aplicación.
        pass
