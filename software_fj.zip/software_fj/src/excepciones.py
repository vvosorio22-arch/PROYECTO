"""Jerarquía de excepciones personalizada del sistema Software FJ.

Todas las excepciones de negocio heredan de :class:`SoftwareFJError`,
lo que permite capturar cualquier error del dominio con un único
``except SoftwareFJError``.

Responsable: Dev 1 — rama ``feature/excepciones-logs``.
"""

from __future__ import annotations


class SoftwareFJError(Exception):
    """Excepción base de todos los errores del sistema Software FJ.

    Atributos:
        mensaje (str): Descripción legible del error.
        codigo (str): Código técnico del error (formato ``FJ-XXX``).
    """

    def __init__(self, mensaje: str, codigo: str = "FJ-000") -> None:
        """Inicializa la excepción con mensaje y código de error.

        Args:
            mensaje: Descripción legible del error.
            codigo: Código técnico en formato ``FJ-XXX``.
        """
        super().__init__(mensaje)
        self.mensaje: str = mensaje
        self.codigo: str = codigo

    def __str__(self) -> str:
        """Devuelve la representación ``[codigo] mensaje`` del error."""
        return f"[{self.codigo}] {self.mensaje}"


class DatoInvalidoError(SoftwareFJError):
    """Error FJ-001: un dato no cumple las reglas de validación."""

    def __init__(self, mensaje: str) -> None:
        """Inicializa el error con el mensaje recibido y código FJ-001."""
        super().__init__(mensaje, "FJ-001")


class ParametroFaltanteError(SoftwareFJError):
    """Error FJ-002: falta un parámetro obligatorio del servicio."""

    def __init__(self, mensaje: str) -> None:
        """Inicializa el error con el mensaje recibido y código FJ-002."""
        super().__init__(mensaje, "FJ-002")


class OperacionNoPermitidaError(SoftwareFJError):
    """Error FJ-003: la operación no está permitida en el estado actual."""

    def __init__(self, mensaje: str) -> None:
        """Inicializa el error con el mensaje recibido y código FJ-003."""
        super().__init__(mensaje, "FJ-003")


class ReservaInvalidaError(SoftwareFJError):
    """Error FJ-004: la reserva es inválida o no pudo completarse."""

    def __init__(self, mensaje: str) -> None:
        """Inicializa el error con el mensaje recibido y código FJ-004."""
        super().__init__(mensaje, "FJ-004")


class ServicioNoDisponibleError(SoftwareFJError):
    """Error FJ-005: el servicio solicitado no está disponible."""

    def __init__(self, mensaje: str) -> None:
        """Inicializa el error con el mensaje recibido y código FJ-005."""
        super().__init__(mensaje, "FJ-005")


class CalculoInconsistenteError(SoftwareFJError):
    """Error FJ-006: el cálculo de un costo arrojó un valor inválido."""

    def __init__(self, mensaje: str) -> None:
        """Inicializa el error con el mensaje recibido y código FJ-006."""
        super().__init__(mensaje, "FJ-006")
