# Software FJ — Sistema Integral de Gestión de Clientes, Servicios y Reservas

**Curso:** Programación 213023 — UNAD, Fase 4

Sistema desarrollado en Python 3.10+ que demuestra arquitectura orientada
a objetos, manejo avanzado de excepciones, logging automático y trabajo
colaborativo con Git. No utiliza bases de datos: toda la información vive
en memoria durante la ejecución y la única persistencia es el archivo
`sistema.log` generado con el módulo `logging` de la librería estándar.

## Requisitos

- Python 3.10 o superior.
- Solo librería estándar: `logging`, `abc`, `enum`, `functools`,
  `datetime`, `re`, `math`, `typing`.

## Instrucciones de ejecución

Desde la raíz del proyecto:

```bash
python main.py
```

El programa ejecuta automáticamente las 14 simulaciones, imprime el
resumen ejecutivo en consola y registra todos los eventos y excepciones
en `sistema.log`. El proceso **siempre** termina con código de salida 0.

## Estructura de carpetas

```text
software_fj/
├── main.py                      # Punto de entrada (ejecuta simulaciones)
├── README.md
├── .gitignore
├── docs/
│   ├── diagrama_clases.md       # Diagrama Mermaid de clases
│   └── CONTRIBUCION.md          # Ramas, commits y responsables
└── src/
    ├── __init__.py
    ├── excepciones.py           # Jerarquía SoftwareFJError (FJ-000 a FJ-006)
    ├── logger_config.py         # Configuración idempotente del logging
    ├── validadores.py           # Reglas de validación reutilizables
    ├── entidad.py               # ABC EntidadSistema (ID + fecha de creación)
    ├── cliente.py               # Cliente encapsulado con propiedades
    ├── servicio.py              # ABC Servicio + aplicar_ajuste (singledispatch)
    ├── reserva_sala.py          # Servicio por horas (+10 % con proyector)
    ├── alquiler_equipo.py       # Servicio por días (+ depósito único)
    ├── asesoria_especializada.py# Servicio por horas (+15 % presencial)
    ├── reserva.py               # Ciclo de vida PENDIENTE/CONFIRMADA/CANCELADA
    ├── gestor.py                # GestorSoftwareFJ (anti-caída)
    └── simulaciones.py          # Las 14 simulaciones automáticas
```

## Diagrama de clases

```mermaid
classDiagram
    class EntidadSistema {
        <<abstract>>
        -ClassVar int _contador
        -str _id
        -datetime _fecha_creacion
        +str id
        +datetime fecha_creacion
        +bool validar()*
        +str resumen()*
    }

    class Cliente {
        -str _nombre
        -str _documento
        -str _correo
        -str _telefono
        +bool validar()
        +str resumen()
    }

    class Servicio {
        <<abstract>>
        -str _nombre
        -float _tarifa_base
        -bool _disponible
        +float calcular_costo(duracion, descuento, impuesto, recargo)*
        +str describir_servicio()*
        +bool validar_parametros()*
        +float aplicar_ajuste(ajuste, base)
        +float _calcular_base(duracion, descuento, impuesto, recargo, factor_extra)
    }

    class ReservaSala {
        -int _capacidad
        -bool _tiene_proyector
        +float calcular_costo(duracion, ...)
    }

    class AlquilerEquipo {
        -str _tipo_hardware
        -int _cantidad
        -float _deposito
        +float calcular_costo(duracion, ...)
    }

    class AsesoriaEspecializada {
        -str _especialidad
        -str _modalidad
        +float calcular_costo(duracion, ...)
    }

    class EstadoReserva {
        <<enumeration>>
        PENDIENTE
        CONFIRMADA
        CANCELADA
    }

    class Reserva {
        -Cliente _cliente
        -Servicio _servicio
        -float _duracion
        -EstadoReserva _estado
        -bool _procesada
        -float _costo_total
        +void confirmar()
        +void cancelar()
        +float procesar(**ajustes)
    }

    class GestorSoftwareFJ {
        -dict _clientes
        -dict _servicios
        -dict _reservas
        +Cliente registrar_cliente(nombre, documento, correo, telefono)
        +Servicio registrar_servicio(servicio)
        +Reserva crear_reserva(id_cliente, id_servicio, duracion)
        +bool confirmar_reserva(id_reserva)
        +float procesar_reserva(id_reserva, **ajustes)
        +bool cancelar_reserva(id_reserva)
        +str resumen_ejecutivo()
    }

    class SoftwareFJError {
        <<exception>>
        -str mensaje
        -str codigo
    }

    EntidadSistema <|-- Cliente
    EntidadSistema <|-- Servicio
    Servicio <|-- ReservaSala
    Servicio <|-- AlquilerEquipo
    Servicio <|-- AsesoriaEspecializada
    EntidadSistema <|-- Reserva
    Reserva --> Cliente
    Reserva --> Servicio
    Reserva --> EstadoReserva
    GestorSoftwareFJ --> Cliente
    GestorSoftwareFJ --> Servicio
    GestorSoftwareFJ --> Reserva
    Exception <|-- SoftwareFJError
```

## Jerarquía de excepciones

| Código | Excepción | Uso principal |
|---|---|---|
| FJ-000 | `SoftwareFJError` | Base de todas las excepciones del dominio |
| FJ-001 | `DatoInvalidoError` | Datos que no superan las reglas de validación |
| FJ-002 | `ParametroFaltanteError` | Parámetro obligatorio de un servicio ausente |
| FJ-003 | `OperacionNoPermitidaError` | Operación inválida según el estado actual |
| FJ-004 | `ReservaInvalidaError` | Reserva inválida o con entidades inexistentes |
| FJ-005 | `ServicioNoDisponibleError` | Servicio marcado como no disponible |
| FJ-006 | `CalculoInconsistenteError` | Resultado de costo no finito o <= 0 |

Evidencia de estructuras de manejo de excepciones:

| Estructura | Ubicación |
|---|---|
| `try/except` | `validadores.py`, `gestor.py` |
| `try/except/else` | `Gestor.registrar_cliente`, `Reserva.confirmar` |
| `try/except/finally` | `Reserva.procesar`, `main()` |
| `raise ... from e` | `Servicio._calcular_base`, `Reserva.procesar`, `Gestor.crear_reserva` |

## Rúbrica vs. módulos

| Pilar de la rúbrica | Puntos | Cobertura en el código |
|---|---|---|
| Manejo avanzado de excepciones | 50 | `excepciones.py` (jerarquía), las 4 estructuras `try`, `raise ... from e`, `logger_config.py` |
| Arquitectura POO | 35 | `entidad.py` (ABC), `cliente.py` (encapsulamiento), `servicio.py` + 3 derivadas (polimorfismo y sobrecarga con `singledispatchmethod`), `reserva.py`, `gestor.py` |
| Simulaciones y logs | 35 | `simulaciones.py` (14 escenarios), `sistema.log`, resumen ejecutivo en consola |
| Trabajo colaborativo GitHub | 30 | 5 ramas `feature/*`, módulos separados, este README, diagrama Mermaid, `docs/CONTRIBUCION.md` |

## Guía de contribución

El desarrollo se organiza en 5 ramas `feature/*`, una por integrante.
Ver [docs/CONTRIBUCION.md](docs/CONTRIBUCION.md) para la convención de
commits y el flujo de Pull Request hacia `main`.

## Checklist de auto-verificación

- [x] Sin bases de datos (solo memoria + `sistema.log`).
- [x] Sin `pass`, `TODO` ni archivos abreviados.
- [x] `try/except`, `try/except/else` y `try/except/finally` presentes.
- [x] `raise ... from e` en 3 sitios o más.
- [x] 14 simulaciones automáticas sin `input()` ni pausas.
- [x] Log con timestamp, nivel, tipo, mensaje, contexto y causa encadenada.
- [x] 3 subclases polimórficas de `Servicio`.
- [x] Sobrecarga simulada con parámetros opcionales y `singledispatchmethod`.
- [x] Sin imports circulares.
- [x] `main()` nunca lanza excepción y siempre retorna 0.
- [x] README con Mermaid y guía de contribución para 5 integrantes.
