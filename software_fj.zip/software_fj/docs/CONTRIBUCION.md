# Guía de contribución — Software FJ

Responsable: Dev 5 — rama `feature/simulaciones-docs`.

Este proyecto se desarrolla en equipo de 5 integrantes sobre un
repositorio GitHub. Cada integrante trabaja en su propia rama
`feature/*` y sus cambios llegan a `main` únicamente mediante Pull
Request.

## Reparto de responsabilidades

| Dev | Rama | Archivos |
|---|---|---|
| 1 | `feature/excepciones-logs` | `src/__init__.py`, `src/excepciones.py`, `src/logger_config.py` |
| 2 | `feature/modelos-base-cliente` | `src/validadores.py`, `src/entidad.py`, `src/cliente.py` |
| 3 | `feature/servicios-polimorfismo` | `src/servicio.py`, `src/reserva_sala.py`, `src/alquiler_equipo.py`, `src/asesoria_especializada.py` |
| 4 | `feature/reservas-gestor` | `src/reserva.py`, `src/gestor.py` |
| 5 | `feature/simulaciones-docs` | `src/simulaciones.py`, `main.py`, `README.md`, `docs/*`, `.gitignore` |

## Orden de dependencias

Para evitar imports circulares, las ramas se integran en este orden:

```text
excepciones → logger_config → validadores → entidad → cliente/servicio
→ reserva_sala / alquiler_equipo / asesoria_especializada → reserva
→ gestor → simulaciones → main
```

## Convención de commits

Usamos commits en español, en imperativo y con prefijo de tipo:

- `feat:` nueva funcionalidad (ej. `feat: agregar jerarquía de excepciones`).
- `fix:` corrección de errores (ej. `fix: validar descuento mayor a 100`).
- `docs:` documentación (ej. `docs: agregar diagrama de clases`).
- `refactor:` cambios internos sin cambiar comportamiento.
- `test:` ajustes a las simulaciones.

Formato completo:

```text
feat(<alcance>): <descripción breve>

<Cuerpo opcional con el detalle del cambio.>
```

## Flujo de trabajo

1. Clonar el repositorio y posicionarse en `main` actualizado:

   ```bash
   git checkout main
   git pull origin main
   ```

2. Crear (o actualizar) la rama propia:

   ```bash
   git checkout -b feature/excepciones-logs
   ```

3. Implementar los archivos asignados y verificar que el proyecto
   completo ejecuta sin errores:

   ```bash
   python main.py
   ```

4. Confirmar y publicar los cambios:

   ```bash
   git add .
   git commit -m "feat(excepciones): definir SoftwareFJError y subtipos"
   git push origin feature/excepciones-logs
   ```

5. Abrir un Pull Request hacia `main` en GitHub, indicando en la
   descripción qué requisitos de la rúbrica cubre el cambio y esperar
   la revisión de al menos un compañero distinto del autor.

6. Resolver los comentarios de revisión; el merge se hace con
   *squash* para mantener `main` con un historial limpio.

7. Tras el merge, todos actualizan su rama local:

   ```bash
   git checkout main && git pull origin main
   git checkout feature/<su-rama> && git merge main
   ```

## Reglas del equipo

- Nunca hacer push directo a `main`: todo pasa por Pull Request.
- No modificar archivos de otra rama salvo acuerdo explícito en el PR.
- Respetar los nombres de clases, métodos y códigos de error del
  contrato de interfaces para evitar errores de importación.
- Antes de pedir revisión, ejecutar `python main.py` y comprobar que
  las 14 simulaciones corren y que `sistema.log` registra las
  excepciones esperadas.
- Los archivos `sistema.log`, `__pycache__/`, `*.pyc` y `.venv/` están
  ignorados por `.gitignore` y no deben subirse al repositorio.
