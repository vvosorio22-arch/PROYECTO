# Diagrama de clases — Software FJ

Responsable: Dev 5 — rama `feature/simulaciones-docs`.

```mermaid
classDiagram
    class EntidadSistema {
        <<abstract>>
        -ClassVar int _contador
        -str _id
        -datetime _fecha_creacion
        +str id
        +datetime fecha_creacion
        +bool validar()*
        +str resumen()*
    }

    class Cliente {
        -str _nombre
        -str _documento
        -str _correo
        -str _telefono
        +bool validar()
        +str resumen()
    }

    class Servicio {
        <<abstract>>
        -str _nombre
        -float _tarifa_base
        -bool _disponible
        +float calcular_costo(duracion, descuento, impuesto, recargo)*
        +str describir_servicio()*
        +bool validar_parametros()*
        +float aplicar_ajuste(ajuste, base)
        +float _calcular_base(duracion, descuento, impuesto, recargo, factor_extra)
    }

    class ReservaSala {
        -int _capacidad
        -bool _tiene_proyector
        +float calcular_costo(duracion, ...)
    }

    class AlquilerEquipo {
        -str _tipo_hardware
        -int _cantidad
        -float _deposito
        +float calcular_costo(duracion, ...)
    }

    class AsesoriaEspecializada {
        -str _especialidad
        -str _modalidad
        +float calcular_costo(duracion, ...)
    }

    class EstadoReserva {
        <<enumeration>>
        PENDIENTE
        CONFIRMADA
        CANCELADA
    }

    class Reserva {
        -Cliente _cliente
        -Servicio _servicio
        -float _duracion
        -EstadoReserva _estado
        -bool _procesada
        -float _costo_total
        +void confirmar()
        +void cancelar()
        +float procesar(**ajustes)
    }

    class GestorSoftwareFJ {
        -dict _clientes
        -dict _servicios
        -dict _reservas
        +Cliente registrar_cliente(nombre, documento, correo, telefono)
        +Servicio registrar_servicio(servicio)
        +Reserva crear_reserva(id_cliente, id_servicio, duracion)
        +bool confirmar_reserva(id_reserva)
        +float procesar_reserva(id_reserva, **ajustes)
        +bool cancelar_reserva(id_reserva)
        +str resumen_ejecutivo()
    }

    class SoftwareFJError {
        <<exception>>
        -str mensaje
        -str codigo
    }

    EntidadSistema <|-- Cliente
    EntidadSistema <|-- Servicio
    Servicio <|-- ReservaSala
    Servicio <|-- AlquilerEquipo
    Servicio <|-- AsesoriaEspecializada
    EntidadSistema <|-- Reserva
    Reserva --> Cliente
    Reserva --> Servicio
    Reserva --> EstadoReserva
    GestorSoftwareFJ --> Cliente
    GestorSoftwareFJ --> Servicio
    GestorSoftwareFJ --> Reserva
    Exception <|-- SoftwareFJError
```

## Relaciones clave

- `EntidadSistema` es la ABC base con ID autoincremental (`ENT-0001`)
  y fecha de creación; `__str__` delega en `resumen()`.
- `Servicio` es ABC con tres métodos abstractos (`calcular_costo`,
  `describir_servicio`, `validar_parametros`) y la sobrecarga simulada
  `aplicar_ajuste` mediante `@singledispatchmethod` (float/int, str,
  dict).
- Las tres subclases (`ReservaSala`, `AlquilerEquipo`,
  `AsesoriaEspecializada`) especializan la unidad de cobro y los
  factores propios (proyector, cantidad + depósito, recargo presencial).
- `Reserva` modela el ciclo de vida con el enum `EstadoReserva` y la
  bandera `_procesada` que impide cancelar una reserva ya procesada.
- `GestorSoftwareFJ` concentra los diccionarios en memoria y actúa como
  capa anti-caída: captura todo `SoftwareFJError`, lo registra y devuelve
  `None`/`False`.
